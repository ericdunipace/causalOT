import torch
import pykeops
import geomloss

torch.manual_seed(23432)

# initalize data
x = torch.randn(100,5)
y = torch.randn(1000,5)
a = torch.FloatTensor([1/100] * 100)
b = torch.FloatTensor([1/1000] * 1000)

blur_list = [0.05,.5,5,50,500] # lambda values
dual_loss = [None] * len(blur_list)
primal_loss = [None] * len(blur_list)

for i in range(len(blur_list)):
  blur = blur_list[i] # set blur
  Sinkhorn = geomloss.SamplesLoss("sinkhorn", p = 2, blur = blur, 
    cost = geomloss.utils.squared_distances,
                      debias = False,
                      potentials = True,
                      verbose = True,
                      scaling = 0.99)
  output = Sinkhorn(a, x, b, y)
  
  # get potentials
  f = output[0]
  g = output[1]
  
  #calculate loss using implied transportation matrix
  cost = torch.cdist(x,y, p = 2)**2
  gamma = ((f.reshape(-1,1) + g - cost)/blur).exp() * a.reshape(-1,1) * b
  primal_loss[i] = torch.sum(gamma * cost)
  
  # compare to dual loss
  dual_loss[i] = torch.sum(f * a) + torch.sum(g * b)

print(primal_loss)
print(dual_loss)
# values don't align
# [tensor(0.0247), tensor(0.3793), tensor(10.3293), tensor(10.0444), tensor(10.3681)]
# tensor(1.7243), tensor(2.7584), tensor(9.9867), tensor(10.4062), tensor(10.3986)]
